# XiguaLiveDanmakuHelper
### 西瓜直播弹幕助手--控制台版

界面版：[q792602257/XiguaDanmakuHelperGUI](https://github.com/q792602257/XiguaDanmakuHelperGUI "C# ver")

### 西瓜直播弹幕接口```api.py```

### 西瓜直播弹幕助手--录播端```WebMain.py```

> - 能够自动进行ffmpeg转码
> - 转码后自动上传至B站
> - 顺便还能自己清理录播的文件（移动到一个位置，执行shell命令，上传百度云）
> - 把录像文件分一定大小保存（B站有限制，但是不知道是多少）
> - 少部分错误包容机制
> - 有一个简单的WEB页面，及简单的控制接口

### 西瓜直播弹幕助手--礼物端```WinMain.py```

### <s>计划更新</s>

### 并没有呢，这段时间太忙了