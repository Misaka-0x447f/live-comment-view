from .User import User

class Danmaku:
    content =""
    user=None
    def __init__(self, json=None):
        if json:
            self.parse(json)
    def parse(self, json):
        self.user = User(json)
        if "extra" in json:
            if "content" in json["extra"]:
                self.content = json["extra"]['content']       
    def __str__(self):
        return "{} 的弹幕: {}".format(self.user,self.content)